package com.example.auryx

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
