﻿import 'package:flutter/material.dart';
import 'dart:async';


void main() => runApp(const AuryxApp());


// ═══════════════════════════════════════════════
// COLORS
// ═══════════════════════════════════════════════
const kBg = Color(0xFF0A0A1A);
const kSurface = Color(0xFF14142B);
const kPrimary = Color(0xFF6366F1);
const kPurple = Color(0xFF8B5CF6);
const kPink = Color(0xFFEC4899);
const kGreen = Color(0xFF10B981);
const kAmber = Color(0xFFF59E0B);
const kBlue = Color(0xFF3B82F6);
const kRed = Color(0xFFF43F5E);
const kTextSec = Color(0xFFA0A0B8);
const kTextDim = Color(0xFF6B6B80);


// ═══════════════════════════════════════════════
// APP
// ═══════════════════════════════════════════════
class AuryxApp extends StatelessWidget {
  const AuryxApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AURYX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(
            primary: kPrimary, secondary: kPurple, surface: kSurface),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}


// ═══════════════════════════════════════════════
// SPLASH SCREEN
// ═══════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}


class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;


  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeIn),
    );
    _scaleAnim = Tween<double>(begin: 0.6, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _controller.forward();


    Timer(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      }
    });
  }


  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [kBg, Color(0xFF1A1033), kBg],
          ),
        ),
        child: Center(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: ScaleTransition(
              scale: _scaleAnim,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 140, height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.08),
                      border: Border.all(
                          color: Colors.white.withOpacity(0.2),
                          width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: kPurple.withOpacity(0.5),
                          blurRadius: 60,
                          spreadRadius: 10,
                        ),
                      ],
                    ),
                    child: Center(
                      child: ShaderMask(
                        shaderCallback: (b) => const LinearGradient(
                          colors: [kPrimary, kPurple, kPink],
                        ).createShader(b),
                        child: const Text(
                          "A",
                          style: TextStyle(
                            fontSize: 70,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                  const Text(
                    "AURYX",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 6,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    "আপনার ডেটা, আপনার নিয়ন্ত্রণ",
                    style: TextStyle(
                      color: kTextSec.withOpacity(0.9),
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 60),
                  SizedBox(
                    width: 40, height: 40,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        kPurple.withOpacity(0.6),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}


class _LoginScreenState extends State<LoginScreen> {
  bool isBangla = true;
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [kBg, Color(0xFF1A1033), kBg],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 20),
                Align(alignment: Alignment.topRight, child: _langToggle()),
                const SizedBox(height: 30),
                _logo(),
                const SizedBox(height: 24),
                Text(isBangla ? "স্বাগতম AURYX-এ" : "Welcome to AURYX",
                    style: const TextStyle(fontSize: 24,
                        fontWeight: FontWeight.bold, color: Colors.white)),
                const SizedBox(height: 8),
                Text(isBangla ? "আপনার ডেটা, আপনার নিয়ন্ত্রণ"
                    : "Your Data, Your Control",
                    style: const TextStyle(fontSize: 13, color: kTextSec)),
                const SizedBox(height: 36),
                _input(isBangla ? "ইমেইল" : "Email",
                    Icons.email_outlined, _emailCtrl),
                const SizedBox(height: 16),
                _passInput(isBangla ? "পাসওয়ার্ড" : "Password"),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const ForgotPasswordScreen()));
                    },
                    child: Text(
                        isBangla ? "পাসওয়ার্ড ভুলে গেছেন?"
                            : "Forgot Password?",
                        style: const TextStyle(color: kPurple,
                            fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(height: 12),
                _gradientButton(
                  isBangla ? "লগইন" : "Login",
                  () {
                    Navigator.pushReplacement(context, MaterialPageRoute(
                        builder: (_) => const DashboardScreen()));
                  },
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(isBangla ? "অ্যাকাউন্ট নেই? " : "No account? ",
                        style: const TextStyle(color: kTextSec, fontSize: 13)),
                    TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(
                            builder: (_) => const RegisterScreen()));
                      },
                      child: Text(isBangla ? "রেজিস্টার" : "Register",
                          style: const TextStyle(color: kPurple,
                              fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(children: [
                  const Expanded(child: Divider(color: Color(0xFF2A2A44))),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(isBangla ? "অথবা" : "or",
                        style: const TextStyle(color: kTextSec, fontSize: 12)),
                  ),
                  const Expanded(child: Divider(color: Color(0xFF2A2A44))),
                ]),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(
                        builder: (_) => const DashboardScreen()));
                  },
                  icon: const Icon(Icons.person_outline, size: 20),
                  label: Text(isBangla ? "গেস্ট হিসেবে দেখুন"
                      : "Continue as Guest"),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: kTextSec,
                    side: const BorderSide(color: Color(0xFF2A2A44)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    minimumSize: const Size(double.infinity, 52),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _logo() {
    return Container(
      width: 100, height: 100,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.5),
        boxShadow: [
          BoxShadow(color: kPurple.withOpacity(0.4),
              blurRadius: 40, spreadRadius: 5),
        ],
      ),
      child: Center(
        child: ShaderMask(
          shaderCallback: (b) => const LinearGradient(
              colors: [kPrimary, kPurple, kPink]).createShader(b),
          child: const Text("A", style: TextStyle(fontSize: 50,
              fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      ),
    );
  }


  Widget _langToggle() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        _langBtn("বাংলা", isBangla, () => setState(() => isBangla = true)),
        _langBtn("English", !isBangla, () => setState(() => isBangla = false)),
      ]),
    );
  }


  Widget _langBtn(String text, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          gradient: active ? const LinearGradient(
              colors: [kPrimary, kPurple]) : null,
          borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(
            color: active ? Colors.white : kTextSec,
            fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }


  Widget _input(String label, IconData icon, TextEditingController ctrl) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  Widget _passInput(String label) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: _passCtrl,
        obscureText: _obscure,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: const Icon(Icons.lock, color: kPurple),
          suffixIcon: IconButton(
            icon: Icon(
              _obscure ? Icons.visibility_off : Icons.visibility,
              color: kTextSec,
            ),
            onPressed: () => setState(() => _obscure = !_obscure),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  Widget _gradientButton(String text, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [kPrimary, kPurple, kPink]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: kPurple.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Center(child: Text(text, style: const TextStyle(
            color: Colors.white, fontSize: 16,
            fontWeight: FontWeight.bold))),
      ),
    );
  }
}
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}


class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📝 রেজিস্টার"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 10),
              Container(
                width: 70, height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.08),
                  border: Border.all(
                      color: Colors.white.withOpacity(0.2), width: 1.5),
                  boxShadow: [
                    BoxShadow(color: kPurple.withOpacity(0.4),
                        blurRadius: 30, spreadRadius: 3),
                  ],
                ),
                child: Center(
                  child: ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                        colors: [kPrimary, kPurple, kPink]).createShader(b),
                    child: const Text("A", style: TextStyle(fontSize: 36,
                        fontWeight: FontWeight.w900, color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text("নতুন অ্যাকাউন্ট তৈরি করুন",
                  style: TextStyle(color: Colors.white,
                      fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text("আপনার ডেটা সুরক্ষিত থাকবে",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 32),
              _field("পূর্ণ নাম", Icons.person, _nameCtrl),
              const SizedBox(height: 14),
              _field("ইমেইল", Icons.email, _emailCtrl,
                  keyboard: TextInputType.emailAddress),
              const SizedBox(height: 14),
              _field("ফোন নম্বর", Icons.phone, _phoneCtrl,
                  keyboard: TextInputType.phone),
              const SizedBox(height: 14),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: TextField(
                  controller: _passCtrl,
                  obscureText: _obscure,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: "পাসওয়ার্ড",
                    labelStyle: const TextStyle(color: kTextSec),
                    prefixIcon: const Icon(Icons.lock, color: kPurple),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscure ? Icons.visibility_off : Icons.visibility,
                        color: kTextSec,
                      ),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 18),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info, color: kPurple, size: 20),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "রেজিস্ট্রেশনের পর ইমেইল ও ফোন ভেরিফিকেশন লাগবে",
                        style: TextStyle(color: kPurple, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () {
                  // নাম সেভ করো
                  if (_nameCtrl.text.isNotEmpty) {
                    AppState.userName = _nameCtrl.text;
                  }
                  if (_emailCtrl.text.isNotEmpty) {
                    AppState.userEmail = _emailCtrl.text;
                  }
                  if (_phoneCtrl.text.isNotEmpty) {
                    AppState.userPhone = _phoneCtrl.text;
                  }
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const OTPScreen(
                          contact: "abu@auryx.app", isEmail: true)));
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [kPrimary, kPurple, kPink]),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: kPurple.withOpacity(0.4),
                          blurRadius: 20, offset: const Offset(0, 8)),
                    ],
                  ),
                  child: const Center(child: Text("অ্যাকাউন্ট তৈরি করুন",
                      style: TextStyle(color: Colors.white,
                          fontSize: 16, fontWeight: FontWeight.bold))),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("অ্যাকাউন্ট আছে? ",
                      style: TextStyle(color: kTextSec, fontSize: 13)),
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("লগইন",
                        style: TextStyle(color: kPurple,
                            fontSize: 13, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl,
      {TextInputType? keyboard}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboard,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }
}
class OTPScreen extends StatefulWidget {
  final String contact;
  final bool isEmail;
  const OTPScreen({super.key, required this.contact, this.isEmail = true});
  @override
  State<OTPScreen> createState() => _OTPScreenState();
}


class _OTPScreenState extends State<OTPScreen> {
  final List<TextEditingController> _controllers =
      List.generate(6, (_) => TextEditingController());


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔐 ভেরিফিকেশন"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    kPrimary.withOpacity(0.2), kPurple.withOpacity(0.2)]),
                  shape: BoxShape.circle,
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: Icon(
                    widget.isEmail ? Icons.email : Icons.phone_android,
                    color: kPurple, size: 60),
              ),
              const SizedBox(height: 24),
              const Text("ভেরিফিকেশন কোড",
                  style: TextStyle(color: Colors.white,
                      fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text("${widget.contact}-এ পাঠানো ৬ ডিজিটের কোড",
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(6, (i) {
                  return Container(
                    width: 44, height: 56,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: _controllers[i].text.isNotEmpty
                              ? kPurple
                              : Colors.white.withOpacity(0.1)),
                    ),
                    child: TextField(
                      controller: _controllers[i],
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      style: const TextStyle(color: Colors.white,
                          fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        counterText: '',
                        border: InputBorder.none,
                      ),
                      onChanged: (v) {
                        if (v.isNotEmpty && i < 5) {
                          FocusScope.of(context).nextFocus();
                        }
                        setState(() {});
                      },
                    ),
                  );
                }),
              ),
              const SizedBox(height: 24),
              const Text("কোড পাননি?",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("✓ আবার পাঠানো হয়েছে")),
                  );
                },
                child: const Text("আবার পাঠান",
                    style: TextStyle(color: kPurple,
                        fontSize: 13, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () {
                  final code = _controllers.map((c) => c.text).join();
                  if (code.length < 6) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("৬ ডিজিট লিখুন"),
                        backgroundColor: kRed,
                      ),
                    );
                    return;
                  }
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("✓ ভেরিফিকেশন সফল"),
                      backgroundColor: kGreen,
                    ),
                  );
                  Navigator.pushReplacement(context, MaterialPageRoute(
                      builder: (_) => const DashboardScreen()));
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [kPrimary, kPurple, kPink]),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: kPurple.withOpacity(0.4),
                          blurRadius: 20, offset: const Offset(0, 8)),
                    ],
                  ),
                  child: const Center(child: Text("ভেরিফাই করুন",
                      style: TextStyle(color: Colors.white,
                          fontSize: 16, fontWeight: FontWeight.bold))),
                ),
              ),
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(
                      builder: (_) => const DashboardScreen()));
                },
                icon: const Icon(Icons.fingerprint, size: 20),
                label: const Text("বায়োমেট্রিক দিয়ে ভেরিফাই"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: kGreen,
                  side: const BorderSide(color: kGreen),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  minimumSize: const Size(double.infinity, 52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}


class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailCtrl = TextEditingController();
  bool _sent = false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔑 পাসওয়ার্ড রিসেট"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    kPrimary.withOpacity(0.2), kPurple.withOpacity(0.2)]),
                  shape: BoxShape.circle,
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: const Icon(Icons.lock_reset,
                    color: kPurple, size: 60),
              ),
              const SizedBox(height: 24),
              Text(_sent ? "ইমেইল পাঠানো হয়েছে" : "পাসওয়ার্ড ভুলে গেছেন?",
                  style: const TextStyle(color: Colors.white,
                      fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(
                  _sent
                      ? "আপনার ইমেইলে একটি লিংক পাঠানো হয়েছে"
                      : "আপনার ইমেইল দিন — আমরা রিসেট লিংক পাঠাবো",
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 32),
              if (!_sent) ...[
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: "ইমেইল",
                      labelStyle: TextStyle(color: kTextSec),
                      prefixIcon: Icon(Icons.email, color: kPurple),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                          horizontal: 16, vertical: 18),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                GestureDetector(
                  onTap: () => setState(() => _sent = true),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [kPrimary, kPurple, kPink]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(color: kPurple.withOpacity(0.4),
                            blurRadius: 20, offset: const Offset(0, 8)),
                      ],
                    ),
                    child: const Center(child: Text("রিসেট লিংক পাঠান",
                        style: TextStyle(color: Colors.white,
                            fontSize: 16, fontWeight: FontWeight.bold))),
                  ),
                ),
              ] else ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: kGreen.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kGreen.withOpacity(0.3)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.check_circle, color: kGreen, size: 24),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "ইমেইল চেক করে লিংকে ট্যাপ করুন",
                          style: TextStyle(color: kGreen, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back, size: 18),
                  label: const Text("লগইনে ফিরে যান"),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: kPurple,
                    side: const BorderSide(color: kPurple),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    minimumSize: const Size(double.infinity, 52),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}


class _DashboardScreenState extends State<DashboardScreen> {
  int _index = 0;


  @override
  Widget build(BuildContext context) {
    final tabs = [
      _homeTab(context),
      const AccountManagementScreen(),
      const TransactionsScreen(),
      const TasksScreen(),
      const SettingsScreen(),
    ];


    return Scaffold(
      backgroundColor: kBg,
      body: tabs[_index],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: kSurface,
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08)))),
        child: BottomNavigationBar(
          currentIndex: _index,
          onTap: (i) => setState(() => _index = i),
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: kPurple,
          unselectedItemColor: kTextDim,
          selectedFontSize: 11,
          unselectedFontSize: 11,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'হোম'),
            BottomNavigationBarItem(icon: Icon(Icons.lock), label: 'অ্যাকাউন্ট'),
            BottomNavigationBarItem(icon: Icon(Icons.payments), label: 'লেনদেন'),
            BottomNavigationBarItem(icon: Icon(Icons.task_alt), label: 'টাস্ক'),
            BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'সেটিংস'),
          ],
        ),
      ),
    );
  }


  Widget _homeTab(BuildContext context) {
    final now = DateTime.now();
    final hour = now.hour;
    String greet = "শুভ সকাল";
    if (hour >= 12 && hour < 17) greet = "শুভ অপরাহ্ন";
    else if (hour >= 17 && hour < 20) greet = "শুভ সন্ধ্যা";
    else if (hour >= 20) greet = "শুভ রাত্রি";


    final months = [
      "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
      "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    ];
    final dateStr = "${now.day} ${months[now.month - 1]} ${now.year}";


    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => setState(() => _index = 4),
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [kPrimary, kPurple, kPink]),
                      boxShadow: [
                        BoxShadow(color: kPurple.withOpacity(0.4),
                            blurRadius: 12, spreadRadius: 1),
                      ],
                    ),
                    child: const CircleAvatar(
                      radius: 24,
                      backgroundColor: kSurface,
                      child: Icon(Icons.person, color: kPurple, size: 26),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(greet, style: const TextStyle(
                          fontSize: 13, color: kTextSec)),
                      const SizedBox(height: 2),
                      Text(AppState.userName, style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                      const SizedBox(height: 2),
                      Text(dateStr, style: const TextStyle(
                          fontSize: 12, color: kTextDim)),
                    ],
                  ),
                ),
                _iconBtn(Icons.search, onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const AdvancedSearchScreen()));
                }),
                const SizedBox(width: 10),
                _iconBtn(Icons.notifications_outlined, badge: "3",
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const AllNotificationsScreen()))),
              ],
            ),
            const SizedBox(height: 28),
            GradientCard(
              icon: Icons.lock_outline,
              title: "Account Management",
              subtitle: "২৩টি অ্যাকাউন্ট",
              colors: const [kPrimary, kPurple],
              onTap: () => setState(() => _index = 1),
            ),
            const SizedBox(height: 16),
            GradientCard(
              icon: Icons.payments_outlined,
              title: "লেনদেন",
              subtitle: "মেস: ৳২,৩০০ • পার্সোনাল: ৳৫০০",
              colors: const [kPink, kPurple],
              onTap: () => setState(() => _index = 2),
            ),
            const SizedBox(height: 28),
            const Text("দ্রুত অ্যাক্সেস", style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: GestureDetector(
                  onTap: () => setState(() => _index = 3),
                  child: _quick(Icons.task_alt, "টাস্ক", "৩/৫", kGreen))),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const NotesScreen())),
                  child: _quick(Icons.note_outlined, "নোট", "১২", kAmber))),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const PlansScreen())),
                  child: _quick(Icons.calendar_month, "প্ল্যান", "৫", kBlue))),
              ],
            ),
            const SizedBox(height: 28),
            const Text("দ্রুত নেভিগেশন", style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const StatisticsScreen())),
                  child: _quick(Icons.bar_chart, "স্ট্যাটস", "রিপোর্ট", kPink))),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const CalendarScreen())),
                  child: _quick(Icons.event, "ক্যালেন্ডার", "সব", kBlue))),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const GoalsScreen())),
                  child: _quick(Icons.flag, "লক্ষ্য", "৪টি", kGreen))),
              ],
            ),
            const SizedBox(height: 28),
            const Text("সাম্প্রতিক কার্যক্রম", style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 12),
            GlassCard(
              child: Column(
                children: [
                  _activity(Icons.check_circle, "৩টি টাস্ক সম্পন্ন", "আজ, ১০:৩০ AM", kGreen),
                  const Divider(color: Color(0xFF2A2A44), height: 20),
                  _activity(Icons.payments, "৳৫০০ লেনদেন যোগ", "আজ, ৯:১৫ AM", kPink),
                  const Divider(color: Color(0xFF2A2A44), height: 20),
                  _activity(Icons.lock, "২টি নতুন অ্যাকাউন্ট", "গতকাল, ৮:০০ PM", kPurple),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }


  Widget _iconBtn(IconData icon, {String? badge, VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          if (badge != null)
            Positioned(right: 4, top: 4,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(color: kRed, shape: BoxShape.circle),
                constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                child: Text(badge, style: const TextStyle(
                    color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center),
              )),
        ],
      ),
    );
  }


  Widget _quick(IconData icon, String title, String count, Color color) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 13, color: kTextSec)),
          const SizedBox(height: 4),
          Text(count, style: const TextStyle(
              fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        ],
      ),
    );
  }


  Widget _activity(IconData icon, String title, String time, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(
                  fontSize: 14, color: Colors.white,
                  fontWeight: FontWeight.w500)),
              const SizedBox(height: 2),
              Text(time, style: const TextStyle(fontSize: 12, color: kTextDim)),
            ],
          ),
        ),
      ],
    );
  }
}
class AccountManagementScreen extends StatelessWidget {
  const AccountManagementScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final cats = [
      {"icon": Icons.currency_bitcoin, "name": "Exchange", "count": "১০", "color": kAmber},
      {"icon": Icons.email_outlined, "name": "Email", "count": "৩", "color": kBlue},
      {"icon": Icons.people_outline, "name": "Social", "count": "২", "color": kPink},
      {"icon": Icons.account_balance, "name": "Banking/Finance", "count": "৫", "color": kGreen},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔐 Account Management"),
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: () {})],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: const TextField(
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "অ্যাকাউন্ট খুঁজুন...",
                    hintStyle: TextStyle(color: kTextDim),
                    prefixIcon: Icon(Icons.search, color: kPurple),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    kPrimary.withOpacity(0.2), kPurple.withOpacity(0.2)]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.lock, color: kPurple),
                    SizedBox(width: 12),
                    Text("মোট ২৩টি অ্যাকাউন্ট", style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15)),
                    Spacer(),
                    Icon(Icons.fingerprint, color: kGreen, size: 20),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ...cats.map((c) => _catCard(context,
                  c["icon"] as IconData, c["name"] as String,
                  c["count"] as String, c["color"] as Color)),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const AddAccountScreen()));
                },
                icon: const Icon(Icons.add),
                label: const Text("Add Category"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: kPurple,
                  side: const BorderSide(color: kPurple),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  minimumSize: const Size(double.infinity, 52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _catCard(BuildContext context, IconData icon, String name,
      String count, Color color) {
    return GestureDetector(
      onTap: () {
        if (name == "Exchange") {
          Navigator.push(context, MaterialPageRoute(
              builder: (_) => const ExchangeScreen()));
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(child: Text(name, style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.w600,
                color: Colors.white))),
            Text("($count)", style: const TextStyle(
                color: kTextSec, fontSize: 14)),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_forward_ios, color: kTextDim, size: 14),
          ],
        ),
      ),
    );
  }
}


class ExchangeScreen extends StatelessWidget {
  const ExchangeScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final items = [
      {"name": "Binance", "emoji": "🟡", "count": "৩"},
      {"name": "Bitget", "emoji": "🟠", "count": "১"},
      {"name": "Bybit", "emoji": "🟣", "count": "২"},
      {"name": "KuCoin", "emoji": "🔵", "count": "১"},
      {"name": "Gate.io", "emoji": "⚪", "count": "১"},
      {"name": "MEXC", "emoji": "🟢", "count": "০"},
      {"name": "OKX", "emoji": "⚫", "count": "১"},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("💱 Exchange"),
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: items.length + 1,
          itemBuilder: (context, i) {
            if (i == items.length) {
              return Padding(
                padding: const EdgeInsets.only(top: 12),
                child: OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.add),
                  label: const Text("Add Category"),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: kPurple,
                    side: const BorderSide(color: kPurple),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    minimumSize: const Size(double.infinity, 52),
                  ),
                ),
              );
            }
            final ex = items[i];
            return GestureDetector(
              onTap: () {
                if (ex["name"] == "Binance") {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const AccountDetailsScreen()));
                }
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Row(
                  children: [
                    Text(ex["emoji"]!, style: const TextStyle(fontSize: 24)),
                    const SizedBox(width: 16),
                    Expanded(child: Text("${ex["name"]} Account",
                        style: const TextStyle(fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: Colors.white))),
                    Text("(${ex["count"]})",
                        style: const TextStyle(
                            color: kTextSec, fontSize: 13)),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward_ios,
                        color: kTextDim, size: 14),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}


class AccountDetailsScreen extends StatelessWidget {
  const AccountDetailsScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final fields = [
      {"label": "নাম", "value": "আবু উবাইদা", "icon": Icons.person},
      {"label": "NID", "value": "1234567890", "icon": Icons.badge},
      {"label": "Email", "value": "abu@auryx.app", "icon": Icons.email},
      {"label": "Number", "value": "+8801712345678", "icon": Icons.phone},
      {"label": "UID", "value": "12345678", "icon": Icons.fingerprint},
      {"label": "Password", "value": "••••••••••", "icon": Icons.lock},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🟡 Binance #1"),
        actions: [
          IconButton(icon: const Icon(Icons.edit), onPressed: () {}),
          IconButton(icon: const Icon(Icons.delete, color: kRed),
              onPressed: () => _confirmDelete(context)),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    kAmber.withOpacity(0.2), kPrimary.withOpacity(0.2)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kAmber.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Text("🟡", style: TextStyle(fontSize: 40)),
                    SizedBox(width: 16),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Binance Account #1", style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold,
                            color: Colors.white)),
                        SizedBox(height: 4),
                        Text("সক্রিয় • ভেরিফাইড",
                            style: TextStyle(fontSize: 12, color: kGreen)),
                      ],
                    )),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ...fields.map((f) => _field(context,
                  f["label"] as String, f["value"] as String,
                  f["icon"] as IconData)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info, color: kPurple, size: 18),
                        SizedBox(width: 8),
                        Text("এই ইমেইল দিয়ে খোলা অন্য অ্যাকাউন্ট",
                            style: TextStyle(color: kPurple,
                                fontWeight: FontWeight.bold, fontSize: 13)),
                      ],
                    ),
                    SizedBox(height: 12),
                    Text("• Binance #2 (UID: 67890)",
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                    SizedBox(height: 4),
                    Text("• Bybit #1 (UID: 11111)",
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _field(BuildContext context, String label, String value, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Icon(icon, color: kPurple, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(
                    fontSize: 11, color: kTextDim)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(
                    fontSize: 15, color: Colors.white,
                    fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.copy, color: kTextSec, size: 18),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("✓ কপি হয়েছে"),
                  duration: Duration(seconds: 1),
                ),
              );
            },
          ),
        ],
      ),
    );
  }


  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kSurface,
        title: const Text("ডিলিট করবেন?",
            style: TextStyle(color: Colors.white)),
        content: const Text(
            "এই অ্যাকাউন্টটি Recycle Bin-এ যাবে। ৩০ দিন পর স্থায়ীভাবে মুছে যাবে।",
            style: TextStyle(color: kTextSec)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("বাতিল", style: TextStyle(color: kTextSec)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("ডিলিট", style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
  }
}
class AddAccountScreen extends StatefulWidget {
  const AddAccountScreen({super.key});
  @override
  State<AddAccountScreen> createState() => _AddAccountScreenState();
}


class _AddAccountScreenState extends State<AddAccountScreen> {
  final _categoryCtrl = TextEditingController();
  final _serviceCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _nidCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _uidCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscurePass = true;


  String selectedCategory = "Exchange";
  String selectedService = "Binance";


  final List<String> categories = ["Exchange", "Email", "Social", "Banking/Finance"];
  final Map<String, List<String>> services = {
    "Exchange": ["Binance", "Bitget", "Bybit", "KuCoin", "Gate.io", "MEXC", "OKX"],
    "Email": ["Gmail", "Outlook", "Yahoo"],
    "Social": ["Facebook", "Instagram", "Twitter", "TikTok"],
    "Banking/Finance": ["Islami Bank", "bKash", "Nagad", "Rocket"],
  };


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("➕ নতুন যোগ করুন"),
        actions: [
          TextButton(
            onPressed: () => _saveAccount(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    kPrimary.withOpacity(0.15), kPurple.withOpacity(0.15)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.add_box, color: kPurple, size: 22),
                        SizedBox(width: 8),
                        Text("নতুন ক্যাটাগরি তৈরি",
                            style: TextStyle(color: Colors.white,
                                fontSize: 15, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text("যেমন: Crypto Wallet, Shopping, Gaming",
                        style: TextStyle(color: kTextSec, fontSize: 11)),
                    const SizedBox(height: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: Colors.white.withOpacity(0.1)),
                      ),
                      child: TextField(
                        controller: _categoryCtrl,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          hintText: "ক্যাটাগরির নাম",
                          hintStyle: TextStyle(color: kTextDim, fontSize: 13),
                          prefixIcon: Icon(Icons.folder,
                              color: kPurple, size: 20),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 14, vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () {
                        if (_categoryCtrl.text.isNotEmpty) {
                          setState(() {
                            categories.add(_categoryCtrl.text);
                            services[_categoryCtrl.text] = [];
                            selectedCategory = _categoryCtrl.text;
                            _categoryCtrl.clear();
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("✓ নতুন ক্যাটাগরি তৈরি হয়েছে"),
                              backgroundColor: kGreen,
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text("ক্যাটাগরি তৈরি করুন"),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: kGreen,
                        side: const BorderSide(color: kGreen),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        minimumSize: const Size(double.infinity, 44),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text("কোন ক্যাটাগরিতে যোগ করবেন?",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: categories.map((c) => _catChip(c)).toList(),
              ),
              const SizedBox(height: 24),
              const Text("সার্ভিস / অ্যাকাউন্টের নাম",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: TextField(
                  controller: _serviceCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: "সার্ভিসের নাম লিখুন...",
                    hintStyle: TextStyle(color: kTextDim, fontSize: 13),
                    prefixIcon: Icon(Icons.business,
                        color: kPurple, size: 20),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 14, vertical: 14),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              if ((services[selectedCategory] ?? []).isNotEmpty) ...[
                const Text("দ্রুত সাজেশন",
                    style: TextStyle(color: kTextDim, fontSize: 11)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: services[selectedCategory]!
                      .map((s) => _serviceChip(s))
                      .toList(),
                ),
                const SizedBox(height: 24),
              ],
              _field("নাম", Icons.person, _nameCtrl),
              const SizedBox(height: 14),
              _field("NID নম্বর", Icons.badge, _nidCtrl,
                  keyboard: TextInputType.number),
              const SizedBox(height: 14),
              _field("ইমেইল", Icons.email, _emailCtrl,
                  keyboard: TextInputType.emailAddress),
              const SizedBox(height: 14),
              _field("ফোন নম্বর", Icons.phone, _phoneCtrl,
                  keyboard: TextInputType.phone),
              const SizedBox(height: 14),
              _field("UID", Icons.fingerprint, _uidCtrl),
              const SizedBox(height: 14),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: TextField(
                  controller: _passCtrl,
                  obscureText: _obscurePass,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: "পাসওয়ার্ড",
                    labelStyle: const TextStyle(color: kTextSec),
                    prefixIcon: const Icon(Icons.lock, color: kPurple),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePass ? Icons.visibility_off : Icons.visibility,
                        color: kTextSec,
                      ),
                      onPressed: () =>
                          setState(() => _obscurePass = !_obscurePass),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 18),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () => _saveAccount(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [kPrimary, kPurple, kPink]),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: kPurple.withOpacity(0.4),
                          blurRadius: 20, offset: const Offset(0, 8)),
                    ],
                  ),
                  child: const Center(child: Text("সেভ করুন",
                      style: TextStyle(color: Colors.white,
                          fontSize: 16, fontWeight: FontWeight.bold))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _catChip(String c) {
    final active = selectedCategory == c;
    return GestureDetector(
      onTap: () => setState(() {
        selectedCategory = c;
        if ((services[c] ?? []).isNotEmpty) {
          selectedService = services[c]!.first;
        }
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(colors: [kPrimary, kPurple]) : null,
          color: active ? null : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: active ? Colors.transparent
                  : Colors.white.withOpacity(0.1)),
        ),
        child: Text(c,
            style: TextStyle(
                color: active ? Colors.white : kTextSec,
                fontSize: 13, fontWeight: FontWeight.w600)),
      ),
    );
  }


  Widget _serviceChip(String s) {
    final active = selectedService == s;
    return GestureDetector(
      onTap: () {
        setState(() => selectedService = s);
        _serviceCtrl.text = s;
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active
              ? kPurple.withOpacity(0.25) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: active ? kPurple : Colors.white.withOpacity(0.1)),
        ),
        child: Text(s,
            style: TextStyle(
                color: active ? kPurple : kTextSec,
                fontSize: 12, fontWeight: FontWeight.w500)),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl,
      {TextInputType? keyboard}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboard,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  void _saveAccount(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("✓ ${_serviceCtrl.text.isEmpty ? selectedService : _serviceCtrl.text} সেভ হয়েছে"),
        backgroundColor: kGreen,
      ),
    );
    Navigator.pop(context);
  }
}


class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});
  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}


class _TransactionsScreenState extends State<TransactionsScreen> {
  int tab = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("💰 লেনদেন"),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => AddTransactionScreen(initialTab: tab),
          ));
        },
        backgroundColor: kPurple,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("নতুন লেনদেন",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(child: _tabBtn("🍽️ মেস", 0)),
                  const SizedBox(width: 8),
                  Expanded(child: _tabBtn("👤 পার্সোনাল", 1)),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [kPink, kPurple]),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tab == 0 ? "মেস ব্যালেন্স" : "পার্সোনাল ব্যালেন্স",
                          style: const TextStyle(color: Colors.white70, fontSize: 13),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tab == 0 ? "৳ ২,৩০০" : "৳ ৫০০",
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(Icons.arrow_downward,
                                color: Colors.white, size: 14),
                            const SizedBox(width: 4),
                            Text(tab == 0 ? "আয়: ৳৮,০০০" : "আয়: ৳১,০০০",
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 12)),
                            const SizedBox(width: 16),
                            const Icon(Icons.arrow_upward,
                                color: Colors.white, size: 14),
                            const SizedBox(width: 4),
                            Text(tab == 0 ? "খরচ: ৳৫,৭০০" : "খরচ: ৳৫০০",
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text("সাম্প্রতিক",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  if (tab == 0) ...[
                    _txItem("আব্বু", "+ ৳৫,০০০", "১ মে", kGreen),
                    _txItem("মেস ভাড়া", "- ৳২,৫০০", "৫ মে", kRed),
                    _txItem("খাবার", "- ৳১,২০০", "৬ মে", kRed),
                    _txItem("ছোট আব্বু", "+ ৳২,০০০", "৩ মে", kGreen),
                    _txItem("পড়াশোনা", "- ৳১,০০০", "৭ মে", kRed),
                  ] else ...[
                    _txItem("রাকিব (ধার)", "- ৳৫০০", "১১ মে", kRed),
                    _txItem("সাব্বির (ফেরত)", "+ ৳৩০০", "১০ মে", kGreen),
                    _txItem("উপহার", "- ৳২০০", "৮ মে", kRed),
                  ],
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }


  Widget _tabBtn(String text, int idx) {
    final active = tab == idx;
    return GestureDetector(
      onTap: () => setState(() => tab = idx),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(colors: [kPrimary, kPurple])
              : null,
          color: active ? null : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: active
                  ? Colors.transparent
                  : Colors.white.withOpacity(0.1)),
        ),
        child: Center(
          child: Text(text,
              style: TextStyle(
                  color: active ? Colors.white : kTextSec,
                  fontWeight: FontWeight.w600,
                  fontSize: 13)),
        ),
      ),
    );
  }


  Widget _txItem(String title, String amount, String date, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
                color == kGreen ? Icons.arrow_downward : Icons.arrow_upward,
                color: color,
                size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(color: Colors.white, fontSize: 14)),
                Text(date,
                    style: const TextStyle(color: kTextDim, fontSize: 11)),
              ],
            ),
          ),
          Text(amount,
              style: TextStyle(
                  color: color, fontSize: 15, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}


class AddTransactionScreen extends StatefulWidget {
  final int initialTab;
  const AddTransactionScreen({super.key, this.initialTab = 0});
  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}


class _AddTransactionScreenState extends State<AddTransactionScreen> {
  late int tab;
  String direction = "income";
  final _amountCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _personCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();


  final messIncomes = ["আব্বু", "ছোট আব্বু", "নিজে", "অন্যান্য"];
  final messExpenses = ["মেস ভাড়া", "খাবার", "পড়াশোনা", "যাতায়াত", "অন্যান্য"];
  final personalIncomes = ["ধার ফেরত", "উপহার", "অন্যান্য"];
  final personalExpenses = ["ধার দেওয়া", "উপহার", "অন্যান্য"];


  String selectedCategory = "আব্বু";


  @override
  void initState() {
    super.initState();
    tab = widget.initialTab;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("➕ নতুন লেনদেন"),
        actions: [
          TextButton(
            onPressed: () => _saveTransaction(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: _tabBtn("🍽️ মেস", 0)),
                  const SizedBox(width: 8),
                  Expanded(child: _tabBtn("👤 পার্সোনাল", 1)),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: _dirBtn("আয়", "income", kGreen,
                      Icons.arrow_downward)),
                  const SizedBox(width: 12),
                  Expanded(child: _dirBtn("খরচ", "expense", kRed,
                      Icons.arrow_upward)),
                ],
              ),
              const SizedBox(height: 20),
              const Text("পরিমাণ",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: direction == "income"
                          ? kGreen.withOpacity(0.4)
                          : kRed.withOpacity(0.4)),
                ),
                child: TextField(
                  controller: _amountCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 24,
                      fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.only(left: 16, right: 8),
                      child: Text("৳",
                          style: TextStyle(
                              color: direction == "income" ? kGreen : kRed,
                              fontSize: 26, fontWeight: FontWeight.bold)),
                    ),
                    prefixIconConstraints:
                        const BoxConstraints(minWidth: 0),
                    hintText: "0",
                    hintStyle: const TextStyle(
                        color: kTextDim, fontSize: 24),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 20),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text("ক্যাটাগরি",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _getCategories()
                    .map((c) => _catChip(c))
                    .toList(),
              ),
              const SizedBox(height: 20),
              _field("বিবরণ", Icons.notes, _descCtrl),
              const SizedBox(height: 14),
              if (tab == 1 && direction == "expense") ...[
                _field("কার নাম", Icons.person, _personCtrl),
                const SizedBox(height: 14),
                _field("ফোন নম্বর", Icons.phone, _phoneCtrl,
                    keyboard: TextInputType.phone),
                const SizedBox(height: 14),
              ],
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: ListTile(
                  leading: const Icon(Icons.calendar_today, color: kPurple),
                  title: const Text("আজকের তারিখ",
                      style: TextStyle(color: kTextSec, fontSize: 12)),
                  subtitle: Text(_getTodayDate(),
                      style: const TextStyle(
                          color: Colors.white, fontSize: 15)),
                  trailing: const Icon(Icons.arrow_forward_ios,
                      color: kTextDim, size: 14),
                ),
              ),
              const SizedBox(height: 24),
              GradientButtonLocal(
                text: "লেনদেন সেভ করুন",
                onTap: () => _saveTransaction(context),
              ),
            ],
          ),
        ),
      ),
    );
  }


  String _getTodayDate() {
    final now = DateTime.now();
    final months = [
      "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
      "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    ];
    return "${now.day} ${months[now.month - 1]} ${now.year}";
  }


  List<String> _getCategories() {
    if (tab == 0) {
      return direction == "income" ? messIncomes : messExpenses;
    } else {
      return direction == "income" ? personalIncomes : personalExpenses;
    }
  }


  Widget _tabBtn(String text, int idx) {
    final active = tab == idx;
    return GestureDetector(
      onTap: () => setState(() {
        tab = idx;
        selectedCategory = _getCategories().first;
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(colors: [kPrimary, kPurple])
              : null,
          color: active ? null : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: active
                  ? Colors.transparent
                  : Colors.white.withOpacity(0.1)),
        ),
        child: Center(
          child: Text(text,
              style: TextStyle(
                  color: active ? Colors.white : kTextSec,
                  fontWeight: FontWeight.w600,
                  fontSize: 13)),
        ),
      ),
    );
  }


  Widget _dirBtn(String text, String value, Color color, IconData icon) {
    final active = direction == value;
    return GestureDetector(
      onTap: () => setState(() {
        direction = value;
        selectedCategory = _getCategories().first;
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: active
              ? color.withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: active ? color : Colors.white.withOpacity(0.1),
              width: active ? 1.5 : 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: active ? color : kTextDim, size: 18),
            const SizedBox(width: 8),
            Text(text,
                style: TextStyle(
                    color: active ? color : kTextSec,
                    fontWeight: FontWeight.w600,
                    fontSize: 14)),
          ],
        ),
      ),
    );
  }


  Widget _catChip(String c) {
    final active = selectedCategory == c;
    return GestureDetector(
      onTap: () => setState(() => selectedCategory = c),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(colors: [kPrimary, kPurple])
              : null,
          color: active ? null : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: active
                  ? Colors.transparent
                  : Colors.white.withOpacity(0.1)),
        ),
        child: Text(c,
            style: TextStyle(
                color: active ? Colors.white : kTextSec,
                fontSize: 13,
                fontWeight: FontWeight.w600)),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl,
      {TextInputType? keyboard}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboard,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  void _saveTransaction(BuildContext context) {
    if (_amountCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("পরিমাণ লিখুন"),
          backgroundColor: kRed,
        ),
      );
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            "✓ ৳${_amountCtrl.text} ${direction == "income" ? "আয়" : "খরচ"} সেভ হয়েছে"),
        backgroundColor: kGreen,
        duration: const Duration(seconds: 2),
      ),
    );
    Navigator.pop(context);
  }
}
class GradientButtonLocal extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const GradientButtonLocal({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [kPrimary, kPurple, kPink]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: kPurple.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Center(child: Text(text, style: const TextStyle(
            color: Colors.white, fontSize: 16,
            fontWeight: FontWeight.bold))),
      ),
    );
  }
}
class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});
  @override
  State<TasksScreen> createState() => _TasksScreenState();
}


class _TasksScreenState extends State<TasksScreen> {
  final tasks = [
    {"title": "মেস ভাড়া দেওয়া", "done": true, "priority": "High"},
    {"title": "পড়াশোনা করা", "done": true, "priority": "Medium"},
    {"title": "আব্বুকে ফোন করা", "done": false, "priority": "High"},
    {"title": "বাজার করা", "done": false, "priority": "Low"},
    {"title": "অ্যাসাইনমেন্ট", "done": false, "priority": "Medium"},
  ];


  @override
  Widget build(BuildContext context) {
    final doneCount = tasks.where((t) => t["done"] == true).length;
    final total = tasks.length;


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📋 টাস্ক"),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kPurple,
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(
              builder: (_) => const AddTaskScreen()));
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [kGreen, kBlue]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.task_alt,
                          color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("আজকের অগ্রগতি",
                              style: TextStyle(
                                  color: Colors.white70, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text("$doneCount / $total সম্পন্ন",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    Text("${((doneCount / total) * 100).toInt()}%",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: tasks.length,
                itemBuilder: (context, i) {
                  final t = tasks[i];
                  final done = t["done"] as bool;
                  final priority = t["priority"] as String;
                  Color priColor = kAmber;
                  if (priority == "High") priColor = kRed;
                  if (priority == "Low") priColor = kGreen;


                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => setState(
                              () => tasks[i]["done"] = !done),
                          child: Container(
                            width: 26, height: 26,
                            decoration: BoxDecoration(
                              color: done ? kGreen : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: done
                                      ? kGreen
                                      : Colors.white.withOpacity(0.3),
                                  width: 2),
                            ),
                            child: done
                                ? const Icon(Icons.check,
                                    color: Colors.white, size: 18)
                                : null,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Text(t["title"] as String,
                              style: TextStyle(
                                  color: done ? kTextDim : Colors.white,
                                  fontSize: 15,
                                  decoration: done
                                      ? TextDecoration.lineThrough
                                      : null)),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: priColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(priority,
                              style: TextStyle(
                                  color: priColor,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key});
  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}


class _AddTaskScreenState extends State<AddTaskScreen> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String priority = "Medium";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📋 নতুন টাস্ক"),
        actions: [
          TextButton(
            onPressed: () => _save(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _field("টাস্কের নাম", Icons.task_alt, _titleCtrl),
              const SizedBox(height: 14),
              _field("বিবরণ", Icons.notes, _descCtrl),
              const SizedBox(height: 14),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: const ListTile(
                  leading: Icon(Icons.calendar_today, color: kPurple),
                  title: Text("তারিখ",
                      style: TextStyle(color: kTextSec, fontSize: 12)),
                  subtitle: Text("১ অক্টোবর ২০২৬",
                      style: TextStyle(color: Colors.white, fontSize: 15)),
                  trailing: Icon(Icons.arrow_forward_ios,
                      color: kTextDim, size: 14),
                ),
              ),
              const SizedBox(height: 20),
              const Text("গুরুত্ব",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _priBtn("Low", kGreen)),
                  const SizedBox(width: 8),
                  Expanded(child: _priBtn("Medium", kAmber)),
                  const SizedBox(width: 8),
                  Expanded(child: _priBtn("High", kRed)),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: const ListTile(
                  leading: Icon(Icons.alarm, color: kPurple),
                  title: Text("রিমাইন্ডার",
                      style: TextStyle(color: kTextSec, fontSize: 12)),
                  subtitle: Text("১০ মিনিট আগে",
                      style: TextStyle(color: Colors.white, fontSize: 15)),
                  trailing: Icon(Icons.arrow_forward_ios,
                      color: kTextDim, size: 14),
                ),
              ),
              const SizedBox(height: 24),
              GradientButtonLocal(
                text: "টাস্ক সেভ করুন",
                onTap: () => _save(context),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _priBtn(String p, Color color) {
    final active = priority == p;
    return GestureDetector(
      onTap: () => setState(() => priority = p),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: active
              ? color.withOpacity(0.25) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: active ? color : Colors.white.withOpacity(0.1),
              width: active ? 1.5 : 1),
        ),
        child: Center(
          child: Text(p,
              style: TextStyle(
                  color: active ? color : kTextSec,
                  fontSize: 13,
                  fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  void _save(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("✓ টাস্ক সেভ হয়েছে"),
        backgroundColor: kGreen,
      ),
    );
    Navigator.pop(context);
  }
}


class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});
  @override
  State<NotesScreen> createState() => _NotesScreenState();
}


class _NotesScreenState extends State<NotesScreen> {
  final notes = [
    {"title": "গুরুত্বপূর্ণ", "body": "মেস ভাড়া ৫ তারিখে দিতে হবে", "color": kRed, "cat": "গুরুত্বপূর্ণ"},
    {"title": "আইডিয়া", "body": "নতুন অ্যাপের ফিচার প্ল্যান", "color": kAmber, "cat": "আইডিয়া"},
    {"title": "পড়াশোনা", "body": "ডেটা স্ট্রাকচার রিভিশন", "color": kGreen, "cat": "পড়াশোনা"},
    {"title": "কেনাকাটা", "body": "চাল, ডাল, তেল", "color": kBlue, "cat": "কেনাকাটা"},
    {"title": "সিকিউরিটি", "body": "Recovery key ব্যাকআপ", "color": kPurple, "cat": "গুরুত্বপূর্ণ"},
    {"title": "মেস", "body": "মেসের বিল ৭ তারিখে", "color": kPink, "cat": "পড়াশোনা"},
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📝 নোট"),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(
              builder: (_) => const AddNoteScreen()));
        },
        backgroundColor: kAmber,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("নতুন নোট",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: GridView.builder(
          padding: const EdgeInsets.all(20),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.85,
          ),
          itemCount: notes.length,
          itemBuilder: (context, i) {
            final n = notes[i];
            final color = n["color"] as Color;
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: color.withOpacity(0.35)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.push_pin, color: color, size: 14),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(n["cat"] as String,
                            style: TextStyle(
                                color: color, fontSize: 10,
                                fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(n["title"] as String,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 14,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text(n["body"] as String,
                        style: const TextStyle(color: kTextSec, fontSize: 12),
                        maxLines: 5,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}


class AddNoteScreen extends StatefulWidget {
  const AddNoteScreen({super.key});
  @override
  State<AddNoteScreen> createState() => _AddNoteScreenState();
}


class _AddNoteScreenState extends State<AddNoteScreen> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  String selectedCat = "গুরুত্বপূর্ণ";


  final cats = [
    {"name": "গুরুত্বপূর্ণ", "color": kRed},
    {"name": "আইডিয়া", "color": kAmber},
    {"name": "পড়াশোনা", "color": kGreen},
    {"name": "কেনাকাটা", "color": kBlue},
    {"name": "ব্যক্তিগত", "color": kPurple},
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📝 নতুন নোট"),
        actions: [
          TextButton(
            onPressed: () => _save(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: TextField(
                  controller: _titleCtrl,
                  style: const TextStyle(color: Colors.white,
                      fontSize: 18, fontWeight: FontWeight.bold),
                  decoration: const InputDecoration(
                    hintText: "শিরোনাম",
                    hintStyle: TextStyle(color: kTextDim),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Container(
                height: 250,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: TextField(
                  controller: _bodyCtrl,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: "নোট লিখুন...",
                    hintStyle: TextStyle(color: kTextDim),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text("ক্যাটাগরি",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: cats.map((c) {
                  final active = selectedCat == c["name"];
                  return GestureDetector(
                    onTap: () => setState(
                        () => selectedCat = c["name"] as String),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: active
                            ? (c["color"] as Color).withOpacity(0.25)
                            : Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: active
                                ? (c["color"] as Color)
                                : Colors.white.withOpacity(0.1)),
                      ),
                      child: Text(c["name"] as String,
                          style: TextStyle(
                              color: active ? c["color"] as Color : kTextSec,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              GradientButtonLocal(
                text: "নোট সেভ করুন",
                onTap: () => _save(context),
              ),
            ],
          ),
        ),
      ),
    );
  }


  void _save(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("✓ নোট সেভ হয়েছে"),
        backgroundColor: kGreen,
      ),
    );
    Navigator.pop(context);
  }
}


class PlansScreen extends StatefulWidget {
  const PlansScreen({super.key});
  @override
  State<PlansScreen> createState() => _PlansScreenState();
}


class _PlansScreenState extends State<PlansScreen> {
  final plans = [
    {"title": "মেস ভাড়া দেওয়া", "date": "৫ মে", "time": "সকাল ১০টা", "color": kRed, "icon": Icons.home},
    {"title": "আব্বুকে ফোন", "date": "৭ মে", "time": "সন্ধ্যা ৭টা", "color": kGreen, "icon": Icons.phone},
    {"title": "লাইব্রেরি যাওয়া", "date": "৯ মে", "time": "সকাল ৯টা", "color": kBlue, "icon": Icons.menu_book},
    {"title": "ডাক্তার অ্যাপয়েন্টমেন্ট", "date": "১২ মে", "time": "দুপুর ২টা", "color": kAmber, "icon": Icons.local_hospital},
    {"title": "বন্ধুর জন্মদিন", "date": "১৫ মে", "time": "সন্ধ্যা ৮টা", "color": kPink, "icon": Icons.cake},
  ];


  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final months = [
      "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
      "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📅 প্ল্যান"),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(
              builder: (_) => const AddPlanScreen()));
        },
        backgroundColor: kBlue,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("নতুন প্ল্যান",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kBlue, kPurple]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(16)),
                      child: Column(
                        children: [
                          Text("${now.day}",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold)),
                          Text(months[now.month - 1],
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 11)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("আজকের প্ল্যান",
                              style: TextStyle(
                                  color: Colors.white70, fontSize: 12)),
                          SizedBox(height: 4),
                          Text("৫টি ইভেন্ট বাকি",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text("আসন্ন ইভেন্ট",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              ...plans.map((p) => Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: (p["color"] as Color).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(14)),
                          child: Icon(p["icon"] as IconData,
                              color: p["color"] as Color, size: 22),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p["title"] as String,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Icon(Icons.calendar_today,
                                      color: kTextDim, size: 11),
                                  const SizedBox(width: 4),
                                  Text(p["date"] as String,
                                      style: const TextStyle(
                                          color: kTextDim, fontSize: 11)),
                                  const SizedBox(width: 10),
                                  const Icon(Icons.access_time,
                                      color: kTextDim, size: 11),
                                  const SizedBox(width: 4),
                                  Text(p["time"] as String,
                                      style: const TextStyle(
                                          color: kTextDim, fontSize: 11)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }
}


class AddPlanScreen extends StatefulWidget {
  const AddPlanScreen({super.key});
  @override
  State<AddPlanScreen> createState() => _AddPlanScreenState();
}


class _AddPlanScreenState extends State<AddPlanScreen> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  String selectedColor = "Blue";


  final colors = [
    {"name": "Blue", "color": kBlue},
    {"name": "Green", "color": kGreen},
    {"name": "Red", "color": kRed},
    {"name": "Amber", "color": kAmber},
    {"name": "Pink", "color": kPink},
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📅 নতুন প্ল্যান"),
        actions: [
          TextButton(
            onPressed: () => _save(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _field("ইভেন্টের নাম", Icons.title, _titleCtrl),
              const SizedBox(height: 14),
              _field("বিবরণ", Icons.notes, _descCtrl),
              const SizedBox(height: 14),
              _field("স্থান", Icons.location_on, _locationCtrl),
              const SizedBox(height: 14),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: const ListTile(
                  leading: Icon(Icons.calendar_today, color: kPurple),
                  title: Text("তারিখ",
                      style: TextStyle(color: kTextSec, fontSize: 12)),
                  subtitle: Text("১ অক্টোবর ২০২৬",
                      style: TextStyle(color: Colors.white, fontSize: 15)),
                ),
              ),
              const SizedBox(height: 20),
              const Text("রঙ",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 10),
              Row(
                children: colors.map((c) {
                  final active = selectedColor == c["name"];
                  return GestureDetector(
                    onTap: () => setState(
                        () => selectedColor = c["name"] as String),
                    child: Container(
                      margin: const EdgeInsets.only(right: 12),
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: c["color"] as Color,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: active ? Colors.white : Colors.transparent,
                            width: active ? 3 : 0),
                      ),
                      child: active
                          ? const Icon(Icons.check,
                              color: Colors.white, size: 20)
                          : null,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              GradientButtonLocal(
                text: "প্ল্যান সেভ করুন",
                onTap: () => _save(context),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  void _save(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("✓ প্ল্যান সেভ হয়েছে"),
        backgroundColor: kGreen,
      ),
    );
    Navigator.pop(context);
  }
}


Widget _placeholder(String title, String sub) {
  return Scaffold(
    backgroundColor: kBg,
    appBar: AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      title: Text(title),
    ),
    body: SafeArea(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: kPurple.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.construction, color: kPurple, size: 60),
            ),
            const SizedBox(height: 24),
            Text(title, style: const TextStyle(
                color: Colors.white, fontSize: 20,
                fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(sub, style: const TextStyle(
                color: kTextSec, fontSize: 14)),
          ],
        ),
      ),
    ),
  );
}
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final items = [
      {"icon": Icons.person, "title": "প্রোফাইল", "color": kBlue, "route": "profile"},
      {"icon": Icons.security, "title": "সিকিউরিটি", "color": kPurple, "route": "security"},
      {"icon": Icons.cloud_upload, "title": "ব্যাকআপ", "color": kGreen, "route": "backup"},
      {"icon": Icons.notifications, "title": "নোটিফিকেশন", "color": kAmber, "route": "notification"},
      {"icon": Icons.language, "title": "ভাষা", "color": kPrimary, "route": "language"},
      {"icon": Icons.palette, "title": "থিম", "color": kPink, "route": "theme"},
      {"icon": Icons.download, "title": "ডেটা Export", "color": kBlue, "route": "export"},
      {"icon": Icons.delete_outline, "title": "Recycle Bin", "color": kRed, "route": "recycle"},
      {"icon": Icons.info_outline, "title": "সম্পর্কে", "color": kTextSec, "route": "about"},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("⚙️ সেটিংস"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const ProfileScreen())),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [kPrimary.withOpacity(0.2),
                        kPurple.withOpacity(0.2)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kPurple.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                            colors: [kPrimary, kPurple, kPink]),
                      ),
                      child: const CircleAvatar(
                        radius: 28,
                        backgroundColor: kSurface,
                        child: Icon(Icons.person, color: kPurple, size: 30),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(AppState.userName,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(AppState.userEmail,
                              style: const TextStyle(
                                  color: kTextSec, fontSize: 12)),
                          const SizedBox(height: 4),
                          const Text("প্রোফাইল দেখুন →",
                              style: TextStyle(
                                  color: kPurple, fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            ...items.map((it) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: (it["color"] as Color).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(it["icon"] as IconData,
                          color: it["color"] as Color, size: 20),
                    ),
                    title: Text(it["title"] as String,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 14)),
                    trailing: const Icon(Icons.arrow_forward_ios,
                        color: kTextDim, size: 14),
                    onTap: () => _route(context, it["route"] as String?),
                  ),
                )),
            const SizedBox(height: 16),
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.08),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kRed.withOpacity(0.3)),
              ),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: kRed.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.warning, color: kRed, size: 20),
                ),
                title: const Text("অ্যাকাউন্ট ডিলিট",
                    style: TextStyle(color: kRed, fontSize: 14)),
                trailing: const Icon(Icons.arrow_forward_ios,
                    color: kTextDim, size: 14),
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const DeleteAccountScreen())),
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (_) => const LoginScreen())),
              icon: const Icon(Icons.logout, size: 18),
              label: const Text("লগআউট"),
              style: OutlinedButton.styleFrom(
                foregroundColor: kTextSec,
                side: const BorderSide(color: kTextDim),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                minimumSize: const Size(double.infinity, 52),
              ),
            ),
          ],
        ),
      ),
    );
  }


  void _route(BuildContext context, String? route) {
    if (route == "profile") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const ProfileScreen()));
    } else if (route == "security") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const SecurityScreen()));
    } else if (route == "backup") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const BackupScreen()));
    } else if (route == "notification") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const NotificationScreen()));
    } else if (route == "language") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const LanguageScreen()));
    } else if (route == "theme") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const ThemeScreen()));
    } else if (route == "export") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const ExportDataScreen()));
    } else if (route == "recycle") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const RecycleBinScreen()));
    } else if (route == "about") {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => const AboutScreen()));
    }
  }
}
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}


class _ProfileScreenState extends State<ProfileScreen> {
  late TextEditingController _nameCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _phoneCtrl;


  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: AppState.userName);
    _emailCtrl = TextEditingController(text: AppState.userEmail);
    _phoneCtrl = TextEditingController(text: AppState.userPhone);
  }


  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("👤 প্রোফাইল"),
        actions: [
          TextButton(
            onPressed: () => _save(context),
            child: const Text("সেভ",
                style: TextStyle(color: kPurple,
                    fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [kPrimary, kPurple, kPink]),
                      boxShadow: [
                        BoxShadow(color: kPurple.withOpacity(0.5),
                            blurRadius: 24, spreadRadius: 2),
                      ],
                    ),
                    child: const CircleAvatar(
                      radius: 60,
                      backgroundColor: kSurface,
                      child: Icon(Icons.person, color: kPurple, size: 60),
                    ),
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: GestureDetector(
                      onTap: () => _showImageOptions(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: const BoxDecoration(
                          color: kPurple,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.camera_alt,
                            color: Colors.white, size: 18),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Text(AppState.userName,
                  style: const TextStyle(color: Colors.white,
                      fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(AppState.userEmail,
                  style: const TextStyle(color: kTextSec, fontSize: 14)),
              const SizedBox(height: 32),
              _field("নাম", Icons.person, _nameCtrl),
              const SizedBox(height: 14),
              _field("ইমেইল", Icons.email, _emailCtrl,
                  keyboard: TextInputType.emailAddress),
              const SizedBox(height: 14),
              _field("ফোন", Icons.phone, _phoneCtrl,
                  keyboard: TextInputType.phone),
            ],
          ),
        ),
      ),
    );
  }


  Widget _field(String label, IconData icon, TextEditingController ctrl,
      {TextInputType? keyboard}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboard,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: kTextSec),
          prefixIcon: Icon(icon, color: kPurple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 18),
        ),
      ),
    );
  }


  void _save(BuildContext context) {
    if (_nameCtrl.text.isNotEmpty) AppState.userName = _nameCtrl.text;
    if (_emailCtrl.text.isNotEmpty) AppState.userEmail = _emailCtrl.text;
    if (_phoneCtrl.text.isNotEmpty) AppState.userPhone = _phoneCtrl.text;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("✓ প্রোফাইল আপডেট হয়েছে"),
        backgroundColor: kGreen,
      ),
    );
  }


  void _showImageOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: kTextDim, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 20),
            const Text("প্রোফাইল ছবি",
                style: TextStyle(color: Colors.white,
                    fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            _imageOption(ctx, Icons.camera_alt, "ক্যামেরা থেকে", kPurple),
            const SizedBox(height: 10),
            _imageOption(ctx, Icons.photo_library, "গ্যালারি থেকে", kBlue),
            const SizedBox(height: 10),
            _imageOption(ctx, Icons.delete, "ছবি মুছুন", kRed),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }


  Widget _imageOption(BuildContext ctx, IconData icon, String text, Color color) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(ctx);
        ScaffoldMessenger.of(ctx).showSnackBar(
          SnackBar(
            content: Text("$text — ডেমো"),
            duration: const Duration(seconds: 2),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 14),
            Text(text, style: TextStyle(color: color,
                fontSize: 15, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}


class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});
  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}


class _SecurityScreenState extends State<SecurityScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔒 সিকিউরিটি"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kGreen.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kGreen.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.verified_user, color: kGreen, size: 30),
                  SizedBox(width: 14),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("আপনার অ্যাকাউন্ট সুরক্ষিত",
                          style: TextStyle(color: Colors.white,
                              fontSize: 15, fontWeight: FontWeight.bold)),
                      SizedBox(height: 4),
                      Text("সব সিকিউরিটি চালু আছে",
                          style: TextStyle(color: kTextSec, fontSize: 12)),
                    ],
                  )),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _t("বায়োমেট্রিক লগইন", "ফিঙ্গারপ্রিন্ট / ফেস আইডি",
                AppState.biometricEnabled, Icons.fingerprint, kGreen,
                (v) => setState(() => AppState.biometricEnabled = v)),
            _t("টু-ফ্যাক্টর অথেনটিকেশন", "ইমেইল + OTP কোড",
                AppState.twoFactorEnabled, Icons.security, kPurple,
                (v) => setState(() => AppState.twoFactorEnabled = v)),
            _t("অটো লক", "৫ মিনিট নিষ্ক্রিয় থাকলে",
                AppState.autoLockEnabled, Icons.lock_clock, kBlue,
                (v) => setState(() => AppState.autoLockEnabled = v)),
          ],
        ),
      ),
    );
  }


  Widget _t(String title, String sub, bool value,
      IconData icon, Color color, Function(bool) onChange) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white,
                    fontSize: 14, fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(color: kTextDim, fontSize: 11)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChange, activeColor: kGreen),
        ],
      ),
    );
  }
}


class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override
  State<BackupScreen> createState() => _BackupScreenState();
}


class _BackupScreenState extends State<BackupScreen> {
  bool autoSync = AppState.autoSync;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("💾 ব্যাকআপ"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [kGreen, kBlue]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.cloud_done, color: Colors.white, size: 30),
                      SizedBox(width: 12),
                      Text("ব্যাকআপ সক্রিয়",
                          style: TextStyle(color: Colors.white,
                              fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  SizedBox(height: 16),
                  Text("শেষ ব্যাকআপ",
                      style: TextStyle(color: Colors.white70, fontSize: 12)),
                  SizedBox(height: 4),
                  Text("আজ, ১১:৪৫ AM",
                      style: TextStyle(color: Colors.white,
                          fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.1)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: kGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.sync, color: kGreen, size: 20),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("অটো-সিঙ্ক",
                            style: TextStyle(color: Colors.white,
                                fontSize: 14, fontWeight: FontWeight.w500)),
                        SizedBox(height: 2),
                        Text("ডেটা বদলালে স্বয়ংক্রিয় ব্যাকআপ",
                            style: TextStyle(color: kTextDim, fontSize: 11)),
                      ],
                    ),
                  ),
                  Switch(
  value: autoSync,
  onChanged: (v) => setState(() {
    autoSync = v;
    AppState.autoSync = v;
  }),
  activeColor: kGreen,
),
                ],
              ),
            ),
            const SizedBox(height: 20),
            GradientButtonLocal(
              text: "এখনই ব্যাকআপ করুন",
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("✓ ব্যাকআপ সফল হয়েছে"),
                    backgroundColor: kGreen,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}


class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});
  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}


class _NotificationScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔔 নোটিফিকেশন"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _t("টাস্ক রিমাইন্ডার", "টাস্কের সময় হওয়ার আগে",
                AppState.taskReminder, Icons.task_alt, kGreen,
                (v) => setState(() => AppState.taskReminder = v)),
            _t("লেনদেন অ্যালার্ট", "নতুন লেনদেন যোগ করলে",
                AppState.transactionAlert, Icons.payments, kPink,
                (v) => setState(() => AppState.transactionAlert = v)),
            _t("ব্যাকআপ নোটিফিকেশন", "ব্যাকআপ সফল হলে",
                AppState.backupAlert, Icons.cloud_upload, kBlue,
                (v) => setState(() => AppState.backupAlert = v)),
            _t("সিকিউরিটি অ্যালার্ট", "নতুন ডিভাইসে লগইন হলে",
                AppState.securityAlert, Icons.security, kPurple,
                (v) => setState(() => AppState.securityAlert = v)),
            _t("প্ল্যান রিমাইন্ডার", "দিনের শুরুতে",
                AppState.planReminder, Icons.calendar_month, kAmber,
                (v) => setState(() => AppState.planReminder = v)),
          ],
        ),
      ),
    );
  }


  Widget _t(String title, String sub, bool value,
      IconData icon, Color color, Function(bool) onChange) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white,
                    fontSize: 14, fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(color: kTextDim, fontSize: 11)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChange, activeColor: kGreen),
        ],
      ),
    );
  }
}
class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});
  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}


class _LanguageScreenState extends State<LanguageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🌐 ভাষা"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _lang("বাংলা", "Bangla", "বাং", true),
            _lang("English", "English", "EN", false),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: kPurple.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: kPurple.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: kPurple, size: 20),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "নির্বাচিত ভাষা সংরক্ষিত হবে",
                      style: TextStyle(color: kPurple, fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }


  Widget _lang(String title, String sub, String code, bool isBanglaOption) {
    final active = AppState.isBangla == isBanglaOption;
    return GestureDetector(
      onTap: () {
        setState(() => AppState.isBangla = isBanglaOption);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isBanglaOption
                ? "✓ ভাষা: বাংলা"
                : "✓ Language: English"),
            backgroundColor: kGreen,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: active ? kPurple.withOpacity(0.15)
              : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: active ? kPurple : Colors.white.withOpacity(0.1),
              width: active ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                gradient: active
                    ? const LinearGradient(colors: [kPrimary, kPurple])
                    : null,
                color: active ? null : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(code,
                    style: TextStyle(
                        color: active ? Colors.white : kTextSec,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(
                      color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(sub, style: const TextStyle(
                      color: kTextDim, fontSize: 12)),
                ],
              ),
            ),
            if (active)
              const Icon(Icons.check_circle, color: kPurple, size: 24),
          ],
        ),
      ),
    );
  }
}


class ThemeScreen extends StatefulWidget {
  const ThemeScreen({super.key});
  @override
  State<ThemeScreen> createState() => _ThemeScreenState();
}


class _ThemeScreenState extends State<ThemeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🎨 থিম"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _th("লাইট", Icons.light_mode, kAmber, false),
            _th("ডার্ক", Icons.dark_mode, kPurple, true),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: kPurple.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: kPurple.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: kPurple, size: 20),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "ডেমোতে থিম পরিবর্তন সীমিত। আসল APK-তে কাজ করবে।",
                      style: TextStyle(color: kPurple, fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }


  Widget _th(String title, IconData icon, Color color, bool isDarkOption) {
    final active = AppState.isDarkMode == isDarkOption;
    return GestureDetector(
      onTap: () {
        setState(() => AppState.isDarkMode = isDarkOption);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isDarkOption ? "✓ ডার্ক মোড" : "✓ লাইট মোড"),
            backgroundColor: kGreen,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.15)
              : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: active ? color : Colors.white.withOpacity(0.1),
              width: active ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(title, style: const TextStyle(
                  color: Colors.white, fontSize: 15,
                  fontWeight: FontWeight.w600)),
            ),
            if (active)
              Icon(Icons.check_circle, color: color, size: 24),
          ],
        ),
      ),
    );
  }
}


class ExportDataScreen extends StatelessWidget {
  const ExportDataScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      {"icon": Icons.lock, "title": "অ্যাকাউন্ট ডেটা", "size": "২৩টি", "color": kPurple},
      {"icon": Icons.payments, "title": "লেনদেন", "size": "১২৪টি", "color": kPink},
      {"icon": Icons.task_alt, "title": "টাস্ক", "size": "৪৫টি", "color": kGreen},
      {"icon": Icons.note, "title": "নোট", "size": "৩২টি", "color": kAmber},
      {"icon": Icons.calendar_month, "title": "প্ল্যান", "size": "১৮টি", "color": kBlue},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📤 ডেটা Export"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kBlue.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info, color: kBlue, size: 24),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "Export করা ডেটা JSON ফরম্যাটে সেভ হবে।",
                        style: TextStyle(color: kBlue, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ...items.map((it) => Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: (it["color"] as Color).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(it["icon"] as IconData,
                              color: it["color"] as Color, size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Text(it["title"] as String,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 14))),
                        Text(it["size"] as String,
                            style: const TextStyle(
                                color: kTextSec, fontSize: 13)),
                      ],
                    ),
                  )),
              const SizedBox(height: 24),
              GradientButtonLocal(
                text: "JSON হিসেবে Export",
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("✓ Export শুরু হয়েছে"),
                      backgroundColor: kGreen,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("ℹ️ সম্পর্কে"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.08),
                  border: Border.all(color: Colors.white.withOpacity(0.2),
                      width: 1.5),
                  boxShadow: [
                    BoxShadow(color: kPurple.withOpacity(0.4),
                        blurRadius: 30, spreadRadius: 3),
                  ],
                ),
                child: Center(
                  child: ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                        colors: [kPrimary, kPurple, kPink]).createShader(b),
                    child: const Text("A", style: TextStyle(fontSize: 44,
                        fontWeight: FontWeight.w900, color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text("AURYX",
                  style: TextStyle(color: Colors.white,
                      fontSize: 26, fontWeight: FontWeight.bold,
                      letterSpacing: 2)),
              const SizedBox(height: 6),
              const Text("Version 2.0.0",
                  style: TextStyle(color: kTextSec, fontSize: 13)),
              const SizedBox(height: 8),
              const Text("আপনার ডেটা, আপনার নিয়ন্ত্রণ",
                  style: TextStyle(color: kPurple, fontSize: 13)),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: const Column(
                  children: [
                    _aboutRow("বিকাশকারী", "আবু উবাইদা"),
                    Divider(color: Color(0xFF2A2A44), height: 20),
                    _aboutRow("ফিচার", "৬০+ স্ক্রিন"),
                    Divider(color: Color(0xFF2A2A44), height: 20),
                    _aboutRow("সিকিউরিটি", "AES-256"),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text("© ২০২৬ AURYX. All rights reserved.",
                  style: TextStyle(color: kTextDim, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}


class _aboutRow extends StatelessWidget {
  final String label;
  final String value;
  const _aboutRow(this.label, this.value);
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: kTextSec, fontSize: 13)),
        Text(value, style: const TextStyle(
            color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }
}


class DeleteAccountScreen extends StatelessWidget {
  const DeleteAccountScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("⚠️ অ্যাকাউন্ট ডিলিট"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: kRed.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: kRed.withOpacity(0.4), width: 2),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: kRed, size: 60),
              ),
              const SizedBox(height: 24),
              const Text("অ্যাকাউন্ট স্থায়ীভাবে ডিলিট করবেন?",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white,
                      fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kRed.withOpacity(0.3)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("⚠️ যা যা মুছে যাবে:",
                        style: TextStyle(color: kRed,
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10),
                    Text("• সব অ্যাকাউন্ট ডেটা",
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                    SizedBox(height: 4),
                    Text("• সব লেনদেন, টাস্ক, নোট",
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                    SizedBox(height: 4),
                    Text("• ক্লাউড ব্যাকআপ",
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("✓ অ্যাকাউন্ট ডিলিট (ডেমো)"),
                      backgroundColor: kRed,
                    ),
                  );
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(
                    color: kRed.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kRed, width: 1.5),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.delete_forever,                         color: kRed),
                      SizedBox(width: 8),
                      Text("স্থায়ীভাবে ডিলিট করুন",
                          style: TextStyle(
                              color: kRed,
                              fontSize: 15,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class AllNotificationsScreen extends StatelessWidget {
  const AllNotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final notifs = [
      {"icon": Icons.task_alt, "title": "৩টি টাস্ক সম্পন্ন",
        "sub": "আজ, ১০:৩০ AM", "color": kGreen, "read": false},
      {"icon": Icons.payments, "title": "৳৫০০ লেনদেন যোগ",
        "sub": "আজ, ৯:১৫ AM", "color": kPink, "read": false},
      {"icon": Icons.lock, "title": "২টি নতুন অ্যাকাউন্ট",
        "sub": "গতকাল, ৮:০০ PM", "color": kPurple, "read": false},
      {"icon": Icons.cloud_done, "title": "ব্যাকআপ সফল হয়েছে",
        "sub": "গতকাল, ১১:৪৫ AM", "color": kBlue, "read": true},
      {"icon": Icons.security, "title": "নতুন ডিভাইসে লগইন",
        "sub": "৩ দিন আগে", "color": kRed, "read": true},
      {"icon": Icons.calendar_month, "title": "আজ ৩টি ইভেন্ট",
        "sub": "৪ দিন আগে", "color": kAmber, "read": true},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔔 সব নোটিফিকেশন"),
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: notifs.length,
          itemBuilder: (context, i) {
            final n = notifs[i];
            final read = n["read"] as bool;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: read
                    ? Colors.white.withOpacity(0.04)
                    : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: read
                        ? Colors.white.withOpacity(0.06)
                        : (n["color"] as Color).withOpacity(0.4)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: (n["color"] as Color).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(n["icon"] as IconData,
                        color: n["color"] as Color, size: 20),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(n["title"] as String,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: read
                                    ? FontWeight.normal
                                    : FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text(n["sub"] as String,
                            style: const TextStyle(
                                color: kTextDim, fontSize: 11)),
                      ],
                    ),
                  ),
                  if (!read)
                    Container(
                      width: 8, height: 8,
                      decoration: BoxDecoration(
                        color: n["color"] as Color,
                        shape: BoxShape.circle,
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}


class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final expenses = [
      {"cat": "মেস ভাড়া", "amount": 2500, "color": kRed, "percent": 44},
      {"cat": "খাবার", "amount": 1200, "color": kAmber, "percent": 21},
      {"cat": "পড়াশোনা", "amount": 1000, "color": kGreen, "percent": 18},
      {"cat": "যাতায়াত", "amount": 600, "color": kBlue, "percent": 11},
      {"cat": "অন্যান্য", "amount": 400, "color": kPurple, "percent": 6},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📊 স্ট্যাটিস্টিক্স"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: _sc("মোট আয়", "৳৮,০০০", kGreen,
                      Icons.arrow_downward)),
                  const SizedBox(width: 12),
                  Expanded(child: _sc("মোট খরচ", "৳৫,৭০০", kRed,
                      Icons.arrow_upward)),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kPrimary, kPurple]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("এই মাসের ব্যালেন্স",
                        style: TextStyle(color: Colors.white70, fontSize: 12)),
                    SizedBox(height: 6),
                    Text("৳ ২,৩০০",
                        style: TextStyle(color: Colors.white,
                            fontSize: 32, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text("খরচের বিভাজন",
                  style: TextStyle(color: Colors.white,
                      fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Column(
                  children: expenses.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 12, height: 12,
                              decoration: BoxDecoration(
                                color: e["color"] as Color,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(child: Text(e["cat"] as String,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 13))),
                            Text("৳${e["amount"]}",
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 13,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(width: 8),
                            Text("${e["percent"]}%",
                                style: const TextStyle(
                                    color: kTextSec, fontSize: 11)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Container(
                          height: 6,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(3),
                          ),
                          child: FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: (e["percent"] as int) / 100,
                            child: Container(
                              decoration: BoxDecoration(
                                color: e["color"] as Color,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _sc(String label, String value, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 6),
              Text(label, style: const TextStyle(color: kTextSec, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(
              color: color, fontSize: 22, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}


class GoalsScreen extends StatelessWidget {
  const GoalsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final goals = [
      {"title": "মাসিক সঞ্চয়", "target": 5000, "current": 2300,
        "color": kGreen, "icon": Icons.savings},
      {"title": "নতুন ল্যাপটপ", "target": 50000, "current": 12000,
        "color": kBlue, "icon": Icons.laptop},
      {"title": "বই পড়া", "target": 20, "current": 7,
        "color": kAmber, "icon": Icons.menu_book},
      {"title": "সাপ্তাহিক ব্যায়াম", "target": 7, "current": 3,
        "color": kPink, "icon": Icons.fitness_center},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🎯 লক্ষ্য"),
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: goals.length,
          itemBuilder: (context, i) {
            final g = goals[i];
            final color = g["color"] as Color;
            final target = g["target"] as int;
            final current = g["current"] as int;
            final percent = (current / target * 100).clamp(0, 100);
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(g["icon"] as IconData,
                            color: color, size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(g["title"] as String,
                              style: const TextStyle(color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          Text("$current / $target",
                              style: const TextStyle(
                                  color: kTextDim, fontSize: 12)),
                        ],
                      )),
                      Text("${percent.toStringAsFixed(0)}%",
                          style: TextStyle(color: color,
                              fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    height: 8,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: percent / 100,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [color, color.withOpacity(0.7)]),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
class RecycleBinScreen extends StatelessWidget {
  const RecycleBinScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final folders = [
      {"icon": Icons.lock, "name": "Account Management", "count": "৩", "color": kPurple},
      {"icon": Icons.payments, "name": "লেনদেন", "count": "৫", "color": kPink},
      {"icon": Icons.task_alt, "name": "টাস্ক", "count": "২", "color": kGreen},
      {"icon": Icons.note, "name": "নোট", "count": "১", "color": kAmber},
      {"icon": Icons.calendar_month, "name": "প্ল্যান", "count": "০", "color": kBlue},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🗑️ Recycle Bin"),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep, color: kRed),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kAmber.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kAmber.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: kAmber, size: 20),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "ডিলিট করা আইটেম ৩০ দিন পর স্বয়ংক্রিয়ভাবে মুছে যাবে",
                        style: TextStyle(color: kAmber, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text("ডিলিট করা আইটেম",
                  style: TextStyle(color: Colors.white,
                      fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              ...folders.map((f) => GestureDetector(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (_) => RecycleFolderScreen(
                          folderName: f["name"] as String,
                          folderColor: f["color"] as Color,
                          folderIcon: f["icon"] as IconData,
                        ),
                      ));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: (f["color"] as Color).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(f["icon"] as IconData,
                                color: f["color"] as Color, size: 24),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Text("📁 ${f["name"]}",
                                style: const TextStyle(fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white)),
                          ),
                          Text("(${f["count"]})",
                              style: const TextStyle(color: kTextSec, fontSize: 13)),
                          const SizedBox(width: 8),
                          const Icon(Icons.arrow_forward_ios,
                              color: kTextDim, size: 14),
                        ],
                      ),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}


class RecycleFolderScreen extends StatelessWidget {
  final String folderName;
  final Color folderColor;
  final IconData folderIcon;
  const RecycleFolderScreen({
    super.key, required this.folderName,
    required this.folderColor, required this.folderIcon,
  });


  @override
  Widget build(BuildContext context) {
    final items = [
      {"title": "🟡 Binance #1", "deleted": "১২ মে ২০২৫, ৩:৪৫ PM", "days": "২৮"},
      {"title": "📧 Gmail", "deleted": "১০ মে ২০২৫, ১১:২০ AM", "days": "২৬"},
      {"title": "🟣 Bybit #1", "deleted": "৮ মে ২০২৫, ৯:১০ PM", "days": "২৪"},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text("📁 $folderName"),
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: items.length,
          itemBuilder: (context, i) {
            final item = items[i];
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item["title"] as String,
                      style: const TextStyle(color: Colors.white,
                          fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text("ডিলিট: ${item["deleted"]}",
                      style: const TextStyle(color: kTextDim, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text("বাকি: ${item["days"]} দিন",
                      style: const TextStyle(color: kAmber, fontSize: 12)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.restore, size: 16),
                        label: const Text("Restore"),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: kGreen,
                          side: const BorderSide(color: kGreen),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      )),
                      const SizedBox(width: 12),
                      Expanded(child: OutlinedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.delete_forever, size: 16),
                        label: const Text("Delete"),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: kRed,
                          side: const BorderSide(color: kRed),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      )),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
// ═══════════════════════════════════════════════
// GLOBAL APP STATE
// ═══════════════════════════════════════════════
class AppState {
  static String userName = "আবু উবাইদা";
  static String userEmail = "abu@auryx.app";
  static String userPhone = "+8801712345678";
  static String? profileImagePath;
  static bool isBangla = true;
  static bool isDarkMode = true;
  static bool biometricEnabled = true;
  static bool twoFactorEnabled = true;
  static bool autoLockEnabled = true;
  static bool taskReminder = true;
  static bool transactionAlert = true;
  static bool backupAlert = true;
  static bool securityAlert = true;
  static bool planReminder = true;
  static bool autoSync = true;
}
class AdvancedSearchScreen extends StatefulWidget {
  const AdvancedSearchScreen({super.key});
  @override
  State<AdvancedSearchScreen> createState() => _AdvancedSearchScreenState();
}


class _AdvancedSearchScreenState extends State<AdvancedSearchScreen> {
  String selectedType = "সব";
  final types = ["সব", "অ্যাকাউন্ট", "লেনদেন", "টাস্ক", "নোট", "প্ল্যান"];


  @override
  Widget build(BuildContext context) {
    final results = [
      {"icon": Icons.lock, "title": "Binance Account",
        "sub": "Exchange • rafi@...", "color": kAmber},
      {"icon": Icons.payments, "title": "৳২,৫০০ মেস ভাড়া",
        "sub": "৫ মে ২০২৬", "color": kRed},
      {"icon": Icons.task_alt, "title": "মেস ভাড়া দেওয়া",
        "sub": "সম্পন্ন", "color": kGreen},
      {"icon": Icons.note, "title": "Recovery key ব্যাকআপ",
        "sub": "গুরুত্বপূর্ণ", "color": kPurple},
    ];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("🔍 অ্যাডভান্সড সার্চ"),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: const TextField(
                      autofocus: true,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: "সব কিছু খুঁজুন...",
                        hintStyle: TextStyle(color: kTextDim),
                        prefixIcon: Icon(Icons.search, color: kPurple),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 16, vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: types.map((t) {
                        final active = selectedType == t;
                        return GestureDetector(
                          onTap: () => setState(() => selectedType = t),
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: active
                                  ? const LinearGradient(
                                      colors: [kPrimary, kPurple])
                                  : null,
                              color: active ? null
                                  : Colors.white.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: active ? Colors.transparent
                                      : Colors.white.withOpacity(0.1)),
                            ),
                            child: Text(t,
                                style: TextStyle(
                                    color: active ? Colors.white : kTextSec,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600)),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: results.map((r) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: (r["color"] as Color).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(r["icon"] as IconData,
                            color: r["color"] as Color, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(r["title"] as String,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 14)),
                          const SizedBox(height: 2),
                          Text(r["sub"] as String,
                              style: const TextStyle(
                                  color: kTextDim, fontSize: 11)),
                        ],
                      )),
                    ],
                  ),
                )).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});
  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}


class _CalendarScreenState extends State<CalendarScreen> {
  int selectedDay = 15;


  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final months = [
      "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
      "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    ];
    final days = ["রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"];


    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("📅 ক্যালেন্ডার"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kBlue, kPurple]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left, color: Colors.white),
                      onPressed: () {},
                    ),
                    Text("${months[now.month - 1]} ${now.year}",
                        style: const TextStyle(color: Colors.white,
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: const Icon(Icons.chevron_right, color: Colors.white),
                      onPressed: () {},
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: days.map((d) => Expanded(
                  child: Center(
                    child: Text(d,
                        style: const TextStyle(color: kTextDim,
                            fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 7,
                    mainAxisSpacing: 6,
                    crossAxisSpacing: 6,
                  ),
                  itemCount: 35,
                  itemBuilder: (context, i) {
                    final day = i - 3;
                    if (day < 1 || day > 31) {
                      return const SizedBox();
                    }
                    final active = day == selectedDay;
                    final hasEvent = [5, 7, 12, 15, 22, 28].contains(day);
                    return GestureDetector(
                      onTap: () => setState(() => selectedDay = day),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: active
                              ? const LinearGradient(
                                  colors: [kPrimary, kPurple]) : null,
                          color: active ? null : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          border: active
                              ? null
                              : Border.all(
                                  color: Colors.white.withOpacity(0.05)),
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Text("$day",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: active
                                        ? FontWeight.bold
                                        : FontWeight.normal)),
                            if (hasEvent)
                              Positioned(
                                bottom: 5,
                                child: Container(
                                  width: 4, height: 4,
                                  decoration: BoxDecoration(
                                    color: active ? Colors.white : kAmber,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
              Text("$selectedDay ${months[now.month - 1]}-এর ইভেন্ট",
                  style: const TextStyle(color: Colors.white,
                      fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              if ([5, 7, 12, 15, 22, 28].contains(selectedDay)) ...[
                _eventItem("মেস ভাড়া দেওয়া", "সকাল ১০টা", kRed),
                _eventItem("লাইব্রেরি যাওয়া", "সন্ধ্যা ৭টা", kBlue),
              ] else
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: const Center(
                    child: Text("এই দিনে কোনো ইভেন্ট নেই",
                        style: TextStyle(color: kTextDim, fontSize: 13)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _eventItem(String title, String time, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 4, height: 40,
            decoration: BoxDecoration(
              color: color, borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white,
                    fontSize: 14, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(time, style: const TextStyle(color: kTextDim, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const GlassCard({super.key, required this.child, this.padding});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: child,
    );
  }
}


class GradientCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final List<Color> colors;
  final VoidCallback onTap;
  const GradientCard({super.key, required this.icon, required this.title,
      required this.subtitle, required this.colors, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft,
              end: Alignment.bottomRight, colors: colors),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [BoxShadow(color: colors.first.withOpacity(0.4),
              blurRadius: 24, offset: const Offset(0, 10))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(16)),
              child: Icon(icon, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 18,
                    fontWeight: FontWeight.bold, color: Colors.white)),
                const SizedBox(height: 4),
                Text(subtitle, style: TextStyle(fontSize: 13,
                    color: Colors.white.withOpacity(0.9))),
              ],
            )),
            const Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
          ],
        ),
      ),
    );
  }
}