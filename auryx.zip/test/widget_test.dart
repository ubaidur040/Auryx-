// AURYX widget + persistence tests.
//
// Replaces the default Flutter counter template test, which referenced a
// non-existent MyApp class and a counter screen this app never had.
// Covers:
//   1. The app launches on the splash screen and navigates to login.
//   2. AppState.save()/load() round-trips profile + settings through
//      SharedPreferences, and load() keeps the built-in defaults when
//      nothing has been stored yet.

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:auryx/main.dart';

void main() {
  testWidgets('App launches on splash screen, then goes to login',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AuryxApp());
    expect(find.byType(SplashScreen), findsOneWidget);
    expect(find.text('AURYX'), findsOneWidget);

    // Splash shows for 3 seconds, then navigates to the login screen.
    await tester.pump(const Duration(seconds: 3));
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.byType(SplashScreen), findsNothing);
  });

  group('AppState persistence', () {
    test('save/load round-trip restores profile and settings', () async {
      SharedPreferences.setMockInitialValues({});

      AppState.userName = 'Test User';
      AppState.userEmail = 'test@example.com';
      AppState.userPhone = '+8801000000000';
      AppState.isBangla = false;
      AppState.isDarkMode = false;
      AppState.biometricEnabled = false;
      AppState.twoFactorEnabled = false;
      AppState.taskReminder = false;
      AppState.autoSync = false;
      await AppState.save();

      // Reset to defaults, then load — saved values must come back.
      AppState.userName = 'আবু উবাইদা';
      AppState.userEmail = 'abu@auryx.app';
      AppState.userPhone = '+8801712345678';
      AppState.isBangla = true;
      AppState.isDarkMode = true;
      AppState.biometricEnabled = true;
      AppState.twoFactorEnabled = true;
      AppState.taskReminder = true;
      AppState.autoSync = true;
      await AppState.load();

      expect(AppState.userName, 'Test User');
      expect(AppState.userEmail, 'test@example.com');
      expect(AppState.userPhone, '+8801000000000');
      expect(AppState.isBangla, isFalse);
      expect(AppState.isDarkMode, isFalse);
      expect(AppState.biometricEnabled, isFalse);
      expect(AppState.twoFactorEnabled, isFalse);
      expect(AppState.taskReminder, isFalse);
      expect(AppState.autoSync, isFalse);
    });

    test('load() with empty storage keeps defaults', () async {
      SharedPreferences.setMockInitialValues({});
      AppState.userName = 'আবু উবাইদা';
      AppState.userEmail = 'abu@auryx.app';
      AppState.userPhone = '+8801712345678';
      AppState.isBangla = true;
      AppState.isDarkMode = true;
      await AppState.load();
      expect(AppState.userName, 'আবু উবাইদা');
      expect(AppState.userEmail, 'abu@auryx.app');
      expect(AppState.userPhone, '+8801712345678');
      expect(AppState.isBangla, isTrue);
      expect(AppState.isDarkMode, isTrue);
    });
  });
}
