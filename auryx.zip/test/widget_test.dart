// AURYX widget + persistence tests.
//
// Replaces the default Flutter counter template test, which referenced a
// non-existent MyApp class and a counter screen this app never had.
// Covers:
//   1. The app launches on the splash screen and navigates to login.
//   2. AppState.save()/load() round-trips profile + settings through
//      SharedPreferences, and load() keeps the built-in defaults when
//      nothing has been stored yet.
//   3. AuthService.errorMessage() maps FirebaseAuth codes to Bengali.
//   4. The email verification screen renders without Firebase.
//   5. Email-link login: error codes, the login-screen button, and the
//      completeEmailLinkSignIn guard when Firebase is not ready.

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:auryx/main.dart';

void main() {
  testWidgets('App launches on splash screen, then goes to login',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AuryxApp());
    expect(find.byType(SplashScreen), findsOneWidget);
    expect(find.text('AURYX'), findsOneWidget);

    // Splash shows for 3 seconds, then navigates to the login screen.
    await tester.pump(const Duration(seconds: 3));
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.byType(SplashScreen), findsNothing);
  });

  group('AppState persistence', () {
    test('save/load round-trip restores profile and settings', () async {
      SharedPreferences.setMockInitialValues({});

      AppState.userName = 'Test User';
      AppState.userEmail = 'test@example.com';
      AppState.userPhone = '+8801000000000';
      AppState.isBangla = false;
      AppState.isDarkMode = false;
      AppState.biometricEnabled = false;
      AppState.twoFactorEnabled = false;
      AppState.taskReminder = false;
      AppState.autoSync = false;
      await AppState.save();

      // Reset to defaults, then load — saved values must come back.
      AppState.userName = 'আবু উবাইদা';
      AppState.userEmail = 'abu@auryx.app';
      AppState.userPhone = '+8801712345678';
      AppState.isBangla = true;
      AppState.isDarkMode = true;
      AppState.biometricEnabled = true;
      AppState.twoFactorEnabled = true;
      AppState.taskReminder = true;
      AppState.autoSync = true;
      await AppState.load();

      expect(AppState.userName, 'Test User');
      expect(AppState.userEmail, 'test@example.com');
      expect(AppState.userPhone, '+8801000000000');
      expect(AppState.isBangla, isFalse);
      expect(AppState.isDarkMode, isFalse);
      expect(AppState.biometricEnabled, isFalse);
      expect(AppState.twoFactorEnabled, isFalse);
      expect(AppState.taskReminder, isFalse);
      expect(AppState.autoSync, isFalse);
    });

    test('load() with empty storage keeps defaults', () async {
      SharedPreferences.setMockInitialValues({});
      AppState.userName = 'আবু উবাইদা';
      AppState.userEmail = 'abu@auryx.app';
      AppState.userPhone = '+8801712345678';
      AppState.isBangla = true;
      AppState.isDarkMode = true;
      await AppState.load();
      expect(AppState.userName, 'আবু উবাইদা');
      expect(AppState.userEmail, 'abu@auryx.app');
      expect(AppState.userPhone, '+8801712345678');
      expect(AppState.isBangla, isTrue);
      expect(AppState.isDarkMode, isTrue);
    });
  });

  group('AuthService', () {
    test('errorMessage maps Firebase codes to Bengali', () {
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'user-not-found')),
        'এই ইমেইলে কোনো অ্যাকাউন্ট নেই।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'wrong-password')),
        'পাসওয়ার্ড ভুল।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'email-already-in-use')),
        'এই ইমেইলে অ্যাকাউন্ট আছে — লগইন করুন।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'network-request-failed')),
        'ইন্টারনেট সংযোগ নেই।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'invalid-action-code')),
        'লিংকটি ভুল বা ব্যবহার হয়ে গেছে।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'expired-action-code')),
        'লিংকের মেয়াদ শেষ — আবার লিংক পাঠান।');
      expect(
        AuthService.errorMessage(
            FirebaseAuthException(code: 'operation-not-allowed')),
        'ইমেইল লিংক লগইন চালু নেই।');
      expect(AuthService.errorMessage(Exception('boom')),
          'কিছু একটা ভুল হয়েছে। আবার চেষ্টা করুন।');
    });

    test('completeEmailLinkSignIn returns false without Firebase',
        () async {
      // Firebase is not initialized in tests, so the guard must refuse
      // without touching FirebaseAuth.
      expect(
          await AuthService.completeEmailLinkSignIn(
              'https://auryx-93b7a.firebaseapp.com/__/auth/action?mode=signIn&oobCode=x'),
          isFalse);
      expect(AuthService.isEmailSignInLink('https://example.com/'), isFalse);
    });

    testWidgets('login screen shows the email-link button',
        (WidgetTester tester) async {
      await tester.pumpWidget(
          const MaterialApp(home: LoginScreen()));
      expect(find.text('ইমেইল লিংক দিয়ে লগইন'), findsOneWidget);
      expect(find.text('লগইন'), findsOneWidget);
    });

    testWidgets('email verification screen renders without Firebase',
        (WidgetTester tester) async {
      // Firebase is not initialized in tests; the screen must still render
      // using the local AppState email fallback.
      await tester.pumpWidget(
          const MaterialApp(home: EmailVerificationScreen()));
      expect(find.text('ইমেইল ভেরিফাই করুন'), findsOneWidget);
      expect(find.text('আমি ভেরিফাই করেছি'), findsOneWidget);
      expect(find.text('আবার পাঠান'), findsOneWidget);
    });
  });
}
